import fs from 'fs/promises';
import path from 'path';

const dataDir = process.env.DATA_DIR || path.join(process.cwd(), 'src', 'data');

export async function readData<T>(filename: string): Promise<T[]> {
  const filePath = path.join(dataDir, filename);
  try {
    const jsonData = await fs.readFile(filePath, 'utf-8');

    if (!jsonData || jsonData.trim() === '') {
      return [];
    }

    const parsedData = JSON.parse(jsonData);

    if (!Array.isArray(parsedData)) {
      console.warn(`[WARN] Conteúdo em ${filename} é JSON válido, mas não é um array.`);
      return [];
    }

    return parsedData.filter(item => item !== null && typeof item === 'object') as T[];
  } catch (error) {
    const nodeError = error as NodeJS.ErrnoException;
    if (nodeError.code === 'ENOENT') {
      console.warn(`[INFO] Arquivo ${filename} não encontrado. Retornando array vazio.`);
      return [];
    }

    console.error(`[ERRO] Falha ao ler ${filename}:`, error);
    return [];
  }
}

export async function writeData<T>(filename: string, data: T[]): Promise<void> {
  const filePath = path.join(dataDir, filename);
  try {
    const jsonString = JSON.stringify(data, null, 2);
    await fs.writeFile(filePath, jsonString, 'utf-8');
  } catch (error) {
    console.error(`[ERRO] Falha ao escrever em ${filename}:`, error);
    throw error;
  }
}

export function generateId(): string {
  return Math.random().toString(36).substr(2, 9);
}